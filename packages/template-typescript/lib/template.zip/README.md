# This is a basic example of how to create a geofs plugin

The entry point is `init.ts`, which includes the logic deciding when to load the script (wait for the page to load, or wait for a specific variable to be added to the page).

The entry point of the plugin itself is main.ts, where you can run the plugin code directly.
